3PC: dewplayer for MODx Revolution
=================================
Author: Kevin Klein (<a href="http://kevinklein.fr/modx/dewplayer/">http://kevinklein.fr/modx/dewplayer/</a>)

Integration to modx based on dew's great flash mp3 player (<a href="http://www.alsacreations.fr/dewplayer-en.html">dewplayer website</a>)
dewplayer flash mp3 player integration snippet for modx revolution.

Installation
============
Simply download through Package Management, and install.


Documentation
=============
Please see the documentation at:
<a href="http://kevinklein.fr/modx/dewplayer/">http://kevinklein.fr/modx/dewplayer/</a>

Feel free to suggest ideas/improvements/bugs on GitHub:
<a href="http://github.com/wildcat54/dewplayer/issues">http://github.com/wildcat54/dewplayer/issues</a>
